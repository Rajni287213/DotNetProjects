﻿/***************************************************************
Name: Aparna Girijia Ashokan            ID: 8983519

Name: Janvi Dhameliya                   ID: 8893709

Name: Rajni Rajni                       ID: 8838072

Name: Rohil Shobhashana                 ID: 8970375

Name: Saksham Sood                      ID: 8983034
****************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_Project
{
    /// <summary>
    /// this page represents the admin panel of the application.
    /// </summary>
    public partial class AdminPanel : System.Web.UI.Page
    {

        /// <summary>
        /// Handles the Page_Load event. Initializes the page when it is loaded.
        /// </summary>
        /// <param name="sender">Source of the event</param>
        /// <param name="e">Event data</param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}