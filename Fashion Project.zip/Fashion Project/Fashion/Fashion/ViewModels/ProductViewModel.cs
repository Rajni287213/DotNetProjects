﻿using Fashion.Models;

namespace Fashion.ViewModels
{
    public class ProductViewModel
    {
        public List<Product> Products { get; set; }

        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int? SelectedCategoryId { get; set; } // To preserve selected filter
    }
}
