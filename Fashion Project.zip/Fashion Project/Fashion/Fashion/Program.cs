﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Fashion.Data;
using Microsoft.AspNetCore.Identity;
using Fashion.Models;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<FashionContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("FashionContext") ?? throw new InvalidOperationException("Connection string 'FashionContext' not found.")));

builder.Services.AddIdentity<User, IdentityRole>()
    .AddEntityFrameworkStores<FashionContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(
    options =>
    {
        options.AccessDeniedPath = "/Account/AccessDenied";
    }
    );

// Add services to the container.
builder.Services.AddControllersWithViews()
     .AddRazorRuntimeCompilation();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();


app.MapControllerRoute(
           name: "areas",
           pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
         );

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

