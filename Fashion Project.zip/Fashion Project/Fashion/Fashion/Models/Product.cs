﻿namespace Fashion.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }
        public decimal Price { get; set; }
        public int? CategoryID { get; set; } // Foreign Key
        public string? Image { get; set; }

        public Category? Category { get; set; } // Navigation property

    }
}
