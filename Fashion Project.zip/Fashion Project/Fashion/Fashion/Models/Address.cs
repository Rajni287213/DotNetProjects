﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace Fashion.Models
{
    public class Address
    {
        
        public int Id { get; set; }
        public string? UserId { get; set; }

        public User? User { get; set; }

        [Required]

        public string AddressLine {  get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string State {  get; set; }

        [Required]
        public string PostalCode { get; set; }
    }
}
