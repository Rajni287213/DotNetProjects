﻿namespace Fashion.Models
{
    public class Order
    {
        public int orderId { get; set; }

        public string UserId { get; set; }

        public User User { get; set; }

        public int AddressId { get; set; }

        public Address Address { get; set; }

        public decimal Amount { get; set; }

        public string Status { get; set; }

        public DateTime CreatedAt { get; set; }

        public List<OrderItem> OrderItems { get; set; }

    }
}
