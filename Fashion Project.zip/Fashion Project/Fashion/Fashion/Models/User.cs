﻿using Microsoft.AspNetCore.Identity;
using System.Data;

namespace Fashion.Models
{
    public class User : IdentityUser
    {
        public string? Role { get; set; }
    }
}
