﻿using System.ComponentModel.DataAnnotations;

namespace Fashion.Models
{
    public class Category
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Category name is required")]
        public string? CategoryName { get; set; }

        public ICollection<Product>? Products { get; set; }
    }
}
