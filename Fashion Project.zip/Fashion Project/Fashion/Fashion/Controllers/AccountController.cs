﻿    using Fashion.Models;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;

    namespace Fashion.Controllers
    {
        public class AccountController : Controller
        {
            private UserManager<User> _userManager;
            private SignInManager<User> _signInManager;

            public AccountController(UserManager<User> userManager, SignInManager<User> signInManager)
            {
                _userManager = userManager;
                _signInManager = signInManager;
            }

            //GET: Account/Register
            public IActionResult Register()
            {
                return View();
            }

            [HttpPost]
            public async Task<IActionResult> Register(string email, string password, string role)
            {

            //check if the user already exist
            var existingUser = await _userManager.FindByEmailAsync(email);
            if (existingUser != null)
            {
                ViewBag.Error = "User already exists, Use another different account";
                return View();
            }
                var user = new User { UserName = email, Email = email, Role = role };
                var result = await _userManager.CreateAsync(user, password);
                if (result.Succeeded) 
                { 
                    await _userManager.AddToRoleAsync(user, role);
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Login", "Account");
                }
                return View();
            }

            //GET: Account/Login
            public IActionResult Login()
            {
                return View();
            }
        //POST: Account/Login
       

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            var result = await _signInManager.PasswordSignInAsync(email, password, false, false);
            if (result.Succeeded)
            {
                var user = await _userManager.FindByEmailAsync(email);

                if (await _userManager.IsInRoleAsync(user, "Admin"))
                {
                    // Redirect to Admin Dashboard area
                    return RedirectToAction("Index", "Home", new { area = "Dashboard" });
                }

                // Redirect to regular user homepage
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid login attempt";
            return View();
        }
        //GET: Account/Logout
        public async Task<IActionResult> Logout()
            {
                await _signInManager.SignOutAsync();
                return RedirectToAction("Index", "Home");
            }
            //GET: Account/AccessDenied
            public IActionResult AccessDenied()
            {
                return View();
            }
        }
    }
