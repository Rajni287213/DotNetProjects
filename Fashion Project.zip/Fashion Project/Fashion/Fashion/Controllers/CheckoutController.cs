﻿using Fashion.Data;
using Fashion.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderModel = Fashion.Models.Order;

namespace Fashion.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly FashionContext _context;
        private readonly UserManager<User> _userManager;

        public CheckoutController(FashionContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var currentuser = await _userManager.GetUserAsync(HttpContext.User);
            var addresses = await _context.Addresses
                .Include(x => x.User)
                .Where(x => x.UserId == currentuser.Id)
                .ToListAsync();

            ViewBag.Addresses = addresses;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(Address address)
        {
            var currentuser = await _userManager.GetUserAsync(HttpContext.User);
            Console.WriteLine("POST request hit");

            if (ModelState.IsValid)
            {
                Console.WriteLine("Model is valid");
                address.UserId = currentuser.Id;
                _context.Addresses.Add(address);

                try
                {
                    await _context.SaveChangesAsync();
                    Console.WriteLine("Address saved successfully");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error saving: " + ex.Message);
                }

                return RedirectToAction(nameof(Index));
            }

            Console.WriteLine("Model is NOT valid");
            foreach (var state in ModelState)
            {
                Console.WriteLine($"{state.Key}: {string.Join(", ", state.Value.Errors.Select(e => e.ErrorMessage))}");
            }

            var addresses = await _context.Addresses
                .Where(x => x.UserId == currentuser.Id)
                .ToListAsync();

            ViewBag.Addresses = addresses;

            return View(address);
        }

        public async Task<IActionResult> Confirm(int addressId)
        {
            var address = await _context.Addresses.FirstOrDefaultAsync(x => x.Id == addressId);
            if (address == null)
            {
                return BadRequest();
            }

            var currentuser = await _userManager.GetUserAsync(HttpContext.User);
            decimal orderCost = 0;

            var carts = await _context.Carts
                .Include(x => x.Product)
                .Where(x => x.UserID == currentuser.Id)
                .ToListAsync();

            if (carts == null || !carts.Any())
            {
                TempData["ErrorMessage"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }

            foreach (var cart in carts)
            {
                orderCost += (cart.Product.Price * cart.Quantity);
            }

            var order = new OrderModel
            {
                AddressId = addressId,
                CreatedAt = DateTime.Now,
                Status = "Order Placed",
                UserId = currentuser.Id,
                Amount = orderCost,
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            foreach (var cart in carts)
            {
                var orderProduct = new OrderItem
                {
                    ProductId = cart.ProductID,
                    OrderId = order.orderId,
                    Price = cart.Product.Price,
                    Quantity = cart.Quantity,
                };
                _context.OrderItems.Add(orderProduct);
            }

            // Clear the cart after placing the order
            _context.Carts.RemoveRange(carts);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Order placed successfully!";
            return RedirectToAction("ThankYou");
        }

        public IActionResult ThankYou()
        {
            return View();
        }
    }
}
