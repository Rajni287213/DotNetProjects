﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Fashion.Data;
using Fashion.ViewModels;
using System.Linq;
using System.Threading.Tasks;

public class ProductController : Controller
{
    private readonly FashionContext _context;

    public ProductController(FashionContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index(int? categoryId, int page = 1, int pageSize = 6)
    {
        var categories = await _context.Category.ToListAsync();
        ViewBag.Categories = new SelectList(categories, "CategoryID", "CategoryName");

        var productsQuery = _context.Products.Include(p => p.Category).AsQueryable();

        if (categoryId.HasValue && categoryId.Value > 0)
        {
            productsQuery = productsQuery.Where(p => p.CategoryID == categoryId.Value);
        }

        int totalProducts = await productsQuery.CountAsync();
        int totalPages = (int)Math.Ceiling(totalProducts / (double)pageSize);

        var products = await productsQuery
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var model = new ProductViewModel
        {
            Products = products,
            CurrentPage = page,
            TotalPages = totalPages,
            SelectedCategoryId = categoryId
        };

        return View(model);
    }
    public async Task<IActionResult> Details(int id)
    {
        var product = await _context.Products
            .Include(p => p.Category) // Include the category for displaying the category name
            .FirstOrDefaultAsync(p => p.ProductId == id);

        if (product == null)
        {
            return NotFound(); // Return a 404 if the product doesn't exist
        }

        return View(product); // Pass the product to the Details view
    }


}