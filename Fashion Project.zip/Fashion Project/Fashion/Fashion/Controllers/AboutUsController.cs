﻿using Microsoft.AspNetCore.Mvc;

namespace Fashion.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
