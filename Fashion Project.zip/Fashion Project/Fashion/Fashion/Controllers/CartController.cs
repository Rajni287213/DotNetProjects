﻿using Fashion.Data;
using Fashion.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Fashion.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        public readonly FashionContext _context;
        public readonly UserManager<User> _userManager;

        public CartController(FashionContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var currentUser = await _userManager.GetUserAsync(HttpContext.User);
            if (currentUser == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cart = await _context.Carts
                .Include(x => x.Product)
                .Where(x => x.UserID == currentUser.Id)
                .ToListAsync();

            decimal totalCost = 0;
            foreach (var cartItem in cart)
            {
                Console.WriteLine($"Product: {cartItem.Product.Name}, Price: {cartItem.Product.Price}, Qty: {cartItem.Quantity}");
                totalCost += cartItem.Product.Price * cartItem.Quantity;
            }


            ViewBag.TotalCost = totalCost;
            

            return View(cart); // List<Cart> will not be null, even if empty
        }

        public async Task<IActionResult> UpdateQuantity(int Id, int qty)
        {
            var product = await _context.Products.Where(x => x.ProductId == Id).FirstOrDefaultAsync();

            if (product == null)
            {
                return BadRequest();
            }
            var currentUser = await _userManager.GetUserAsync(HttpContext.User);

            var cartItem = await _context.Carts.Where(x => x.UserID == currentUser.Id)
                .Where(x => x.ProductID == Id)
                .FirstOrDefaultAsync();
            if (cartItem == null)
            {
                return BadRequest();
            }
            cartItem.Quantity = qty;
            _context.Carts.Update(cartItem);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        [Authorize]
        public async Task<IActionResult> AddToCart(int Id, int qty = 1)
        {
            var currentUser = await _userManager.GetUserAsync(HttpContext.User);
            if (currentUser == null)
            {
                // Redirect to Login page if not logged in
                return RedirectToAction("Login", "Account");
            }

            // Check if the product already exists in the user's cart
            var existingCartItem = await _context.Carts
                .Where(x => x.UserID == currentUser.Id && x.ProductID == Id)
                .FirstOrDefaultAsync();

            if (existingCartItem != null)
            {
                // Product already exists, redirect with a message
                TempData["ErrorMessage"] = "This product is already in your cart!";
                return RedirectToAction("Index"); // Redirect back to the cart page
            }

            var product = await _context.Products.Where(x => x.ProductId == Id).FirstOrDefaultAsync();
            if (product == null)
            {
                return BadRequest();
            }

            var cart = new Cart { ProductID = Id, Quantity = qty, UserID = currentUser.Id };
            _context.Add(cart);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Product added to cart!";
            return RedirectToAction("Index");
        }


        [HttpGet]
        public async Task<IActionResult> Remove(int cartId)
        {
            var cartItem = await _context.Carts.FindAsync(cartId);
            if (cartItem == null)
            {
                Console.WriteLine($"No cart found with ID {cartId}");
                return BadRequest();
            }
            _context.Carts.Remove(cartItem);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
