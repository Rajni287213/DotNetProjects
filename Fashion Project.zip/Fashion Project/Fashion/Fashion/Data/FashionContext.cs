﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore;
//using Fashion.Models;
//using Microsoft.AspNetCore.Identity;

//namespace Fashion.Data
//{
//    public class FashionContext : IdentityDbContext<User>
//    {
//        public FashionContext(DbContextOptions<FashionContext> options)
//            : base(options)
//        {
//        }

//        public DbSet<Product> Products { get; set; } = default!;
//        public DbSet<Category> Category { get; set; } = default!;
//        public DbSet<Cart> Carts { get; set; }

//        public DbSet<Address> Addresses { get; set; } = default!;
//        public DbSet<Order> Orders { get; set; }
//        public DbSet<OrderItem> OrderItems { get; set; }

//        protected override void OnModelCreating(ModelBuilder builder)
//        {
//            base.OnModelCreating(builder);

//            builder.Entity<IdentityRole>().HasData(
//                new IdentityRole { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
//                new IdentityRole { Id = "2", Name = "User", NormalizedName = "USER" }
//                );
//        }
//    }
//}


using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Fashion.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Fashion.Data
{
    public class FashionContext : IdentityDbContext<User>
    {
        public FashionContext(DbContextOptions<FashionContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; } = default!;
        public DbSet<Category> Category { get; set; } = default!;
        public DbSet<Cart> Carts { get; set; }

        public DbSet<Address> Addresses { get; set; } = default!;
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
                new IdentityRole { Id = "2", Name = "User", NormalizedName = "USER" }
            );

            builder.Entity<Category>().HasData(
                new Category { CategoryID = 2, CategoryName = "Necklace" },
                new Category { CategoryID = 3, CategoryName = "Earrings" },
                new Category { CategoryID = 4, CategoryName = "Rings" },
                new Category { CategoryID = 5, CategoryName = "Bridal Jewelry" },
                new Category { CategoryID = 6, CategoryName = "Bangles" }
            );

            builder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 3,
                    Name = "Celestial Charm Necklace",
                    ShortDescription = "Elegant gold-plated necklace with star and moon pendants.",
                    LongDescription = "Inspired by the night sky, this delicate necklace features shimmering celestial charms in a minimal gold finish. Lightweight and perfect for layering, it adds a dreamy touch to any outfit. Crafted with hypoallergenic materials.",
                    Price = 34.99M,
                    CategoryID = 2,
                    Image = "/img/Products/283dd949-1b0a-48c7-859c-8f97ae473949.jpeg"
                },
                new Product
                {
                    ProductId = 4,
                    Name = "Pearl Glow Pendant",
                    ShortDescription = "Classic pearl pendant on a fine silver chain.",
                    LongDescription = " A timeless piece designed for elegance, this necklace showcases a single luminous freshwater pearl, set on a sterling silver chain. Ideal for both casual looks and formal occasions. Tarnish-resistant and suitable for sensitive skin.",
                    Price = 42.50M,
                    CategoryID = 2,
                    Image = "/img/Products/c8ee6fe1-9291-49c6-a81c-846797a21e60.jpeg"
                },
                new Product
                {
                    ProductId = 5,
                    Name = "Boho Bead Layer Necklace",
                    ShortDescription = "Triple-layered necklace with earthy beads and charms.",
                    LongDescription = "Channeling a free-spirited, bohemian vibe, this necklace features three dainty layers with colorful beads, gold-tone accents, and rustic charm details. Versatile and lightweight, it pairs perfectly with sundresses and casual wear.",
                    Price = 28.75M,
                    CategoryID = 2,
                    Image = "/img/Products/7dc668bb-ebec-4c06-8a43-75cd698f9a1f.jpg"
                },
                new Product
                {
                    ProductId = 6,
                    Name = "Minimal Heart Chain",
                    ShortDescription = "Dainty chain with tiny heart-shaped centerpiece.",
                    LongDescription = "Subtle and sweet, this gold-plated necklace features a single heart charm on a minimalist chain. Perfect for everyday wear or as a thoughtful gift. The adjustable chain ensures a comfortable, custom fit.",
                    Price = 22.00M,
                    CategoryID = 2,
                    Image = "/img/Products/fa3d708f-cbdd-43e5-b919-fe0c1e3aedd5.jpg"
                },
                new Product
                {
                    ProductId = 7,
                    Name = "Royal Gem Statement Necklace",
                    ShortDescription = "Bold statement necklace with multicolor gemstones.",
                    LongDescription = "Turn heads with this luxurious statement piece, featuring a cluster of faceted gemstones in vibrant jewel tones. Set in a gold-tone frame, the necklace adds a regal flair to eveningwear or special occasions.",
                    Price = 59.95M,
                    CategoryID = 2,
                    Image = "/img/Products/96149150-2e1a-4e9e-b2e9-861152e52942.jpg"
                },
                new Product
                {
                    ProductId = 8,
                    Name = "Twilight Drop Earrings",
                    ShortDescription = "Sparkling drop earrings with star-shaped crystals.",
                    LongDescription = "These enchanting earrings feature cascading crystals with delicate star motifs, adding a hint of sparkle and elegance. Perfect for evening events or adding a celestial charm to your outfit. Lightweight and hypoallergenic.",
                    Price = 29.99M,
                    CategoryID = 3,
                    Image = "/img/Products/09dc2525-cf4f-459c-881f-3dc518aea4f7.jpg"
                },
                new Product
                {
                    ProductId = 9,
                    Name = "Pearl Bliss Studs",
                    ShortDescription = "Classic pearl stud earrings for everyday elegance.",
                    LongDescription = "Simple yet timeless, these pearl studs are made with high-quality freshwater pearls, mounted on a sterling silver base. Comfortable for all-day wear and a perfect accessory for both work and casual attire.",
                    Price = 18.50M,
                    CategoryID = 3,
                    Image = "/img/Products/f31da09c-5f8d-4032-9c89-5e072cf18c9e.jpg"
                },
                new Product
                {
                    ProductId = 10,
                    Name = " Boho Fringe Hoops",
                    ShortDescription = "Large hoops with beaded fringe detailing.",
                    LongDescription = "These statement earrings bring bohemian flair with their textured gold hoops and multi-colored beaded fringe. A fun, festive choice for festivals or vacations. Nickel-free and handcrafted for uniqueness.",
                    Price = 36.75M,
                    CategoryID = 3,
                    Image = "/img/Products/f533b12e-8c93-4254-863b-f23940a094b3.jpg"
                },
                new Product
                {
                    ProductId = 11,
                    Name = "Crystal Leaf Crawlers",
                    ShortDescription = "Elegant ear crawlers with leaf-shaped crystals.",
                    LongDescription = "Designed to climb delicately along the earlobe, these crawler earrings feature a shimmering leaf pattern made of rhinestones. A glamorous choice for weddings or date nights. Includes secure, curved backing for a snug fit.",
                    Price = 24.99M,
                    CategoryID = 3,
                    Image = "/img/Products/3c312fe1-2fe4-45eb-b290-8735c2bb1f5b.jpg"
                },
                new Product
                {
                    ProductId = 12,
                    Name = "Luna Opal Ring",
                    ShortDescription = "Dainty opal ring with a moon-inspired shimmer.",
                    LongDescription = " The Luna Opal Ring features a luminous synthetic opal set in a gold-plated band, inspired by the glow of the moon. Its soft iridescence changes color in the light, making it an eye-catching everyday piece or a special gift.",
                    Price = 27.99M,
                    CategoryID = 4,
                    Image = "/img/Products/fa44c02f-e80d-4ab7-965c-484b109317e3.jpg"
                },
                new Product
                {
                    ProductId = 13,
                    Name = "Vintage Rose Ring",
                    ShortDescription = "Antique-style rose gold ring with floral detailing.",
                    LongDescription = "This vintage-inspired piece boasts an intricately sculpted rose design with delicate vines wrapping around the finger. Plated in rose gold, it brings romance and charm to any outfit — perfect for nature lovers and vintage enthusiasts.",
                    Price = 19.99M,
                    CategoryID = 4,
                    Image = "/img/Products/e26ac6a1-3da4-4ad3-9792-96f8340ab7a6.jpg"
                },
                new Product
                {
                    ProductId = 14,
                    Name = "Infinity Knot Ring",
                    ShortDescription = "Symbolic infinity knot ring for lasting connections.",
                    LongDescription = "Representing eternal love and unity, this minimalist infinity knot ring is crafted from sterling silver with a polished finish. Ideal for couples, friendships, or as a daily reminder of strength and commitment.",
                    Price = 22.00M,
                    CategoryID = 4,
                    Image = "/img/Products/448c71e3-4054-4070-ab98-d270b5e5ee2d.jpg"
                },
                new Product
                {
                    ProductId = 15,
                    Name = "Crystal Crown Ring",
                    ShortDescription = "Dazzling crystal-studded ring with crown shape.",
                    LongDescription = "Channel your inner queen with the Crystal Crown Ring — a regal design featuring tiny cubic zirconia stones that shimmer like diamonds. The tiara-like setting adds elegance to casual and formal wear alike.",
                    Price = 34.95M,
                    CategoryID = 4,
                    Image = "/img/Products/bef0586a-2515-411d-a3d3-67679f19eb6a.jpg"
                },
                new Product
                {
                    ProductId = 16,
                    Name = "Majestic Sapphire and Diamond Necklace Set",
                    ShortDescription = "A luxurious sapphire and diamond necklace set that exudes elegance and opulence.",
                    LongDescription = "The Majestic Sapphire and Diamond Necklace Set is an extravagant bridal piece designed to make a bold statement. The set features a beautifully crafted necklace adorned with deep blue sapphires and brilliant diamonds, arranged in an intricate pattern. Set in 18K white gold, the necklace is paired with matching earrings that reflect the same luxurious design. This set is perfect for brides who want to shine with sophistication and grandeur, adding a touch of royal elegance to their wedding day ensemble.",
                    Price = 450.00M,
                    CategoryID = 5,
                    Image = "/img/Products/8bcd3351-640b-4e60-bcdd-89dabf994e4d.jpg"
                },
                new Product
                {
                    ProductId = 17,
                    Name = "'Opulent Gold and Ruby Bridal Set",
                    ShortDescription = "A traditional gold and ruby bridal set that combines vintage charm with modern luxury.",
                    LongDescription = "The Opulent Gold and Ruby Bridal Set is a stunning combination of intricate design and luxurious gemstones. Crafted from 22K yellow gold, this heavy jewelry set includes a bold necklace, matching earrings, and a statement bracelet, all featuring large, vibrant rubies surrounded by sparkling diamonds. The set is designed to make an unforgettable impact on your wedding day, offering a rich and luxurious aesthetic that is both timeless and regal. Ideal for brides who love traditional yet extravagant jewelry, this set ensures you feel like royalty on your special day.",
                    Price = 550.50M,
                    CategoryID = 5,
                    Image = "/img/Products/4d0427cc-1b14-4750-bd00-a414d4d3de19.jpg"
                },
                new Product
                {
                    ProductId = 18,
                    Name = "'Imperial Kundan Necklace Set",
                    ShortDescription = "A breathtaking Kundan necklace set, intricately designed for a grand bridal look.",
                    LongDescription = "The Imperial Kundan Necklace Set is an opulent bridal jewelry piece that combines traditional Kundan craftsmanship with modern luxury. This heavy set includes a grand necklace with multiple layers, earrings, and a maang tikka, all designed with detailed Kundan work, complemented by exquisite meenakari and stone embellishments. The vibrant stones and gold plating create a regal and majestic appearance, perfect for brides seeking to add a touch of grandeur and cultural heritage to their wedding day. Whether paired with a royal saree or lehenga, this set will make any bride the center of attention.",
                    Price = 600.00M,
                    CategoryID = 5,
                    Image = "/img/Products/415b0df5-243b-47f2-b9c5-8239b5414e4a.jpg"
                }
            );
        }
    }
}